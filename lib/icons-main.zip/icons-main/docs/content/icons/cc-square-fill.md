---
title: CC square fill
categories:
  - Shapes
tags:
  - "creative commons"
---
