---
title: Bar chart
categories:
  - Data
tags:
  - chart
  - graph
  - analytics
---
