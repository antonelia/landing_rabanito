---
title: 1 circle
categories:
  - Shapes
tags:
  - number
  - numeral
---
